import SwiftUI

#if canImport(UIKit)
import UIKit
#elseif canImport(AppKit)
import AppKit
#endif

// Logo View Component
struct LogoView: View {
    let imageName: String
    let width: CGFloat
    let height: CGFloat
    
    var body: some View {
        Group {
#if canImport(UIKit)
            if let image = UIImage(named: imageName) {
                Image(uiImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: width, height: height)
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(color: .gray.opacity(0.3), radius: 2, x: 1, y: 1)
            } else {
                // Fallback placeholder
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: width, height: height)
                    .overlay(
                        Text("Logo")
                            .font(.caption)
                            .foregroundColor(.gray)
                    )
            }
#elseif canImport(AppKit)
            if let image = NSImage(named: imageName) {
                Image(nsImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: width, height: height)
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(color: .gray.opacity(0.3), radius: 2, x: 1, y: 1)
            } else {
                // Fallback placeholder
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: width, height: height)
                    .overlay(
                        Text("Logo")
                            .font(.caption)
                            .foregroundColor(.gray)
                    )
            }
#else
            // Fallback placeholder (sin UIKit/AppKit)
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.gray.opacity(0.3))
                .frame(width: width, height: height)
                .overlay(
                    Text("Logo")
                        .font(.caption)
                        .foregroundColor(.gray)
                )
#endif
        }
    }
}

struct ContentView: View {
    @StateObject private var classifier = WirelessClassifier()
    @State private var sampleData: [Float] = []
    @State private var isGenerating = false
    @State private var selectedSignalType = "Random"
    @State private var selectedRealFile = "lte_g30_gentbrugge_f806MHz_r6.bin"
    @State private var testCount = 0
    @State private var successCount = 0
    
    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                // Header
                VStack(spacing: 8) {
                    HStack {
                        Image(systemName: "antenna.radiowaves.left.and.right")
                            .font(.title)
                            .foregroundColor(.blue)
                        Text("NAS Signal Classifier")
                            .font(.title)
                            .fontWeight(.bold)
                    }
                    
                    Text("Real-time Core ML Inference")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                        .padding(.vertical, 4)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)
                }
                
                // Logos Section
                VStack(spacing: 12) {
                    Text("Collaborating Institutions")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    // First row of logos
                    HStack(spacing: 20) {
                        LogoView(imageName: "logo_CSIC", width: 80, height: 80)
                        LogoView(imageName: "Logo_Momentum_Negativo_Circular", width: 80, height: 80)
                        LogoView(imageName: "Next_Generation", width: 80, height: 80)
                    }
                    
                    // Second row of logos
                    HStack(spacing: 20) {
                        LogoView(imageName: "PRTR", width: 80, height: 80)
                        LogoView(imageName: "logo_doraito", width: 80, height: 80)
                        LogoView(imageName: "imse", width: 80, height: 80)
                    }
                }
                .padding(.vertical, 12)
                .padding(.horizontal, 16)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(12)
                
                // Model Status Card
                VStack(spacing: 12) {
                    HStack {
                        Image(systemName: "brain.head.profile")
                            .foregroundColor(.green)
                        Text("Model Status")
                            .font(.headline)
                        Spacer()
                        HStack(spacing: 8) {
                            Circle()
                                .fill(classifier.isModelLoaded ? Color.green : Color.red)
                                .frame(width: 8, height: 8)
                            Text(classifier.isModelLoaded ? "Active" : "Inactive")
                                .font(.caption)
                                .foregroundColor(classifier.isModelLoaded ? .green : .red)
                        }
                    }
                    
                    if classifier.isModelLoaded {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Core ML Engine")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Text("Neural Engine")
                                    .font(.caption)
                                    .foregroundColor(.green)
                            }
                            Spacer()
                            VStack(alignment: .trailing, spacing: 4) {
                                Text("Parameters")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Text("\(classifier.modelParameterCount)")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                            }
                        }
                        
                        // Model status indicator
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                            Text("REAL Trained Model (93.8% accuracy)")
                                .font(.caption)
                                .foregroundColor(.green)
                                .fontWeight(.medium)
                        }
                        .padding(.top, 8)
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(12)
            
                // Inference Results Card
                VStack(spacing: 15) {
                    HStack {
                        Image(systemName: "waveform")
                            .foregroundColor(.blue)
                        Text("Inference Results")
                            .font(.headline)
                        Spacer()
                    }
                    
                    // Main Prediction
                    VStack(spacing: 8) {
                        Text("PREDICTION")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .fontWeight(.semibold)
                        Text(classifier.classificationResult)
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.blue)
                            .multilineTextAlignment(.center)
                    }
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(10)
                    
                    // Probability Bars
                    if !classifier.allProbabilities.isEmpty {
                        VStack(spacing: 8) {
                            Text("CONFIDENCE LEVELS")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .fontWeight(.semibold)
                            
                            ForEach(classifier.allProbabilities.indices, id: \.self) { index in
                                let prob = classifier.allProbabilities[index]
                                let parts = prob.components(separatedBy: ": ")
                                let tech = parts[0]
                                let value = parts[1].replacingOccurrences(of: "%", with: "")
                                let confidence = Float(value) ?? 0.0
                                
                                HStack {
                                    Text(tech)
                                        .font(.caption)
                                        .fontWeight(.medium)
                                        .frame(width: 50, alignment: .leading)
                                    
                                    GeometryReader { geometry in
                                        ZStack(alignment: .leading) {
                                            Rectangle()
                                                .fill(Color.gray.opacity(0.2))
                                                .frame(height: 8)
                                                .cornerRadius(4)
                                            
                                            Rectangle()
                                                .fill(tech == "LTE" ? .red : tech == "DVB-T" ? .orange : .green)
                                                .frame(width: geometry.size.width * CGFloat(confidence / 100), height: 8)
                                                .cornerRadius(4)
                                        }
                                    }
                                    .frame(height: 8)
                                    
                                    Text(String(format: "%.1f%%", confidence))
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                        .frame(width: 40, alignment: .trailing)
                                }
                            }
                        }
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.05))
                .cornerRadius(12)
            
                // Control Panel
                VStack(spacing: 15) {
                    HStack {
                        Image(systemName: "slider.horizontal.3")
                            .foregroundColor(.orange)
                        Text("Signal Control")
                            .font(.headline)
                        Spacer()
                    }
                    
                    // Data Source Selector
                    VStack(spacing: 8) {
                        Text("DATA SOURCE")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .fontWeight(.semibold)
                        
                        HStack(spacing: 8) {
                            Button(action: {
                                selectedSignalType = "Random"
                            }) {
                                Text("Synthetic")
                                    .font(.caption)
                                    .fontWeight(.medium)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(selectedSignalType == "Random" ? Color.blue : Color.gray.opacity(0.2))
                                    .foregroundColor(selectedSignalType == "Random" ? .white : .primary)
                                    .cornerRadius(8)
                            }
                            
                            Button(action: {
                                selectedSignalType = "Real"
                            }) {
                                Text("Real Data")
                                    .font(.caption)
                                    .fontWeight(.medium)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(selectedSignalType == "Real" ? Color.blue : Color.gray.opacity(0.2))
                                    .foregroundColor(selectedSignalType == "Real" ? .white : .primary)
                                    .cornerRadius(8)
                            }
                        }
                        
                        // Real File Selector (only show when Real Data is selected)
                        if selectedSignalType == "Real" {
                            VStack(spacing: 4) {
                                Text("REAL SIGNAL FILES")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .fontWeight(.semibold)
                                
                                HStack(spacing: 8) {
                                    ForEach(classifier.getAvailableTestFiles(), id: \.name) { file in
                                        Button(action: {
                                            selectedRealFile = file.name
                                        }) {
                                            Text(file.type)
                                                .font(.caption)
                                                .fontWeight(.medium)
                                                .padding(.horizontal, 8)
                                                .padding(.vertical, 6)
                                                .background(selectedRealFile == file.name ? Color.green : Color.gray.opacity(0.2))
                                                .foregroundColor(selectedRealFile == file.name ? .white : .primary)
                                                .cornerRadius(6)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    // Generate Button
                    Button(action: generateSampleData) {
                        HStack(spacing: 12) {
                            if isGenerating {
                                ProgressView()
                                    .scaleEffect(0.8)
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            } else {
                                Image(systemName: "play.circle.fill")
                                    .font(.title2)
                            }
                            Text(isGenerating ? "Processing..." : "Run Inference")
                                .font(.headline)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(isGenerating)
                }
                .padding()
                .background(Color.gray.opacity(0.05))
                .cornerRadius(12)
                
                // Performance Metrics
                VStack(spacing: 15) {
                    HStack {
                        Image(systemName: "chart.bar.fill")
                            .foregroundColor(.green)
                        Text("Performance Metrics")
                            .font(.headline)
                        Spacer()
                    }
                    
                    HStack(spacing: 20) {
                        VStack(spacing: 4) {
                            Text("Tests")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text("\(testCount)")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.blue)
                        }
                        
                        Button(action: {
                            classifier.resetAccuracyTracking()
                            testCount = 0
                            successCount = 0
                        }) {
                            Text("Reset")
                                .font(.caption)
                                .fontWeight(.medium)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.red.opacity(0.2))
                                .foregroundColor(.red)
                                .cornerRadius(6)
                        }
                        
                        Spacer()
                        
                        VStack(spacing: 4) {
                            Text("Real Accuracy")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(classifier.realTimeAccuracy)
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.green)
                        }
                        
                        Spacer()
                        
                        VStack(spacing: 4) {
                            Text("Current")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(selectedSignalType)
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.orange)
                        }
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.05))
                .cornerRadius(12)
            }
            .padding()
        }
        .background(Color.black)
    }
    
    private func generateSampleData() {
        isGenerating = true
        
        if selectedSignalType == "Real" {
            // Use real data from .bin files
            let expectedType = classifier.getAvailableTestFiles().first { $0.name == selectedRealFile }?.type ?? "Unknown"
            classifier.classifyRealSignal(filename: selectedRealFile, expectedType: expectedType)
            
            // Update test counter (for display purposes)
            testCount += 1
            
        } else {
            // Generate synthetic data (original functionality)
            let signalTypes = ["LTE", "DVB-T", "WiFi"]
            let signalTypeToGenerate = signalTypes.randomElement() ?? "LTE"
            
            // Generate different signal patterns based on selected type
            sampleData = (0..<2048).map { i in
                let frequency = Float(i) * 0.1
                
                switch signalTypeToGenerate {
                case "LTE":
                    // LTE-like signal (OFDM characteristics)
                    let real = cos(frequency) + Float.random(in: -0.1...0.1)
                    let imag = sin(frequency) + Float.random(in: -0.1...0.1)
                    return [real, imag]
                case "DVB-T":
                    // DVB-T signal (different modulation)
                    let real = cos(frequency * 0.5) + Float.random(in: -0.2...0.2)
                    let imag = sin(frequency * 0.5) + Float.random(in: -0.2...0.2)
                    return [real, imag]
                case "WiFi":
                    // WiFi signal (802.11 characteristics)
                    let real = cos(frequency * 2.0) + Float.random(in: -0.15...0.15)
                    let imag = sin(frequency * 2.0) + Float.random(in: -0.15...0.15)
                    return [real, imag]
                default:
                    return [0.0, 0.0]
                }
            }.flatMap { $0 }
            
            // Update test counter (for display purposes)
            testCount += 1
            
            // Store expected type for accuracy calculation
            classifier.expectedType = signalTypeToGenerate
            
            // Classify the signal
            classifier.classifySignal(iqData: sampleData)
        }
        
        isGenerating = false
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
