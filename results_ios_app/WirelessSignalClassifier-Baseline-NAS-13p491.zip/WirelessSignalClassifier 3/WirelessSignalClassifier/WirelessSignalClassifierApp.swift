//
//  WirelessSignalClassifierApp.swift
//  WirelessSignalClassifier
//
//  Created by Jaime Arevalo on 29/09/25.
//

import SwiftUI

@main
struct WirelessSignalClassifierApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
